Sup zach you shitwad
